import streamlit as st
import pandas as pd
import datetime
import os

# Load or create CSV file
def load_data():
    if os.path.exists("expenses.csv"):
        return pd.read_csv("expenses.csv", parse_dates=['Date'])
    else:
        df = pd.DataFrame(columns=["Date", "Category", "Amount", "Note"])
        df.to_csv("expenses.csv", index=False)
        return df

def save_data(df):
    df.to_csv("expenses.csv", index=False)

st.title("Student Expense Logger")

# Input form
with st.form("expense_form"):
    date = st.date_input("Date", value=datetime.date.today())
    category = st.selectbox("Category", ["Food", "Travel", "Books", "Stationery", "Entertainment", "Other"])
    amount = st.number_input("Amount", min_value=0.0, format="%.2f")
    note = st.text_input("Note (optional)")
    submitted = st.form_submit_button("Add Expense")

# Load data
expenses = load_data()

# Add new expense
if submitted:
    new_expense = pd.DataFrame({
        "Date": [date],
        "Category": [category],
        "Amount": [amount],
        "Note": [note]
    })
    expenses = pd.concat([expenses, new_expense], ignore_index=True)
    save_data(expenses)
    st.success("Expense added successfully!")

# Display data
st.subheader("All Expenses")
st.dataframe(expenses.sort_values(by="Date", ascending=False))

# Summary by category
st.subheader("Summary by Category")
st.bar_chart(expenses.groupby("Category")["Amount"].sum())

# Summary by date
st.subheader("Summary by Date")
daily = expenses.groupby("Date")["Amount"].sum()
st.line_chart(daily)

# Download CSV
st.subheader("Download Your Data")
st.download_button("Download CSV", data=expenses.to_csv(index=False), file_name="expenses.csv")